# websearch_module.py
# Extras din server.py — modulul complet Web Search
# v1.3.0 — FluidSynth build, RMS normalization in main app

# ── DEPENDENȚE ──────────────────────────────────────────────────────────────
import os, re, json, sqlite3, threading, time, datetime, uuid, requests
from contextlib import contextmanager

# ── WS SQLITE CACHE ───────────────────────────────────────────────────────────

WS_DB_PATH = os.path.join(DATA_DIR, 'ws_cache.db')
_db_lock = threading.Lock()


def _db_conn():
    conn = sqlite3.connect(WS_DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def _db_init():
    with _db_lock:
        conn = _db_conn()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS ws_cache (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                query_key    TEXT NOT NULL,
                query        TEXT NOT NULL,
                reason       TEXT,
                url          TEXT,
                title        TEXT,
                summary      TEXT,
                full_content TEXT,
                content_size INTEGER DEFAULT 0,
                success      INTEGER DEFAULT 1,
                created_at   REAL NOT NULL
            )
        ''')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_query_key ON ws_cache(query_key)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_url ON ws_cache(url)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_created ON ws_cache(created_at)')
        conn.commit()
        conn.close()


_db_init()


def _cache_get(query_key, ttl_seconds):
    """Caută în cache după query_key normalizat. Returnează row sau None."""
    if ttl_seconds <= 0:
        return None
    cutoff = time.time() - ttl_seconds
    with _db_lock:
        conn = _db_conn()
        row = conn.execute(
            'SELECT * FROM ws_cache WHERE query_key=? AND created_at>? ORDER BY created_at DESC LIMIT 1',
            (query_key, cutoff)
        ).fetchone()
        conn.close()
    return row


def _cache_get_by_url(url, ttl_seconds):
    """Caută în cache după URL exact. Util pentru deduplicare cross-query."""
    if ttl_seconds <= 0:
        return None
    cutoff = time.time() - ttl_seconds
    with _db_lock:
        conn = _db_conn()
        row = conn.execute(
            'SELECT * FROM ws_cache WHERE url=? AND created_at>? ORDER BY created_at DESC LIMIT 1',
            (url, cutoff)
        ).fetchone()
        conn.close()
    return row


def _cache_store(query_key, query, reason, url, title, summary, full_content, content_size, success=1):
    with _db_lock:
        conn = _db_conn()
        conn.execute(
            '''INSERT INTO ws_cache
               (query_key, query, reason, url, title, summary, full_content, content_size, success, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)''',
            (query_key, query, reason, url, title, summary, full_content, content_size, success, time.time())
        )
        conn.commit()
        conn.close()


def _cache_clear():
    with _db_lock:
        conn = _db_conn()
        conn.execute('DELETE FROM ws_cache')
        conn.commit()
        conn.close()


def _cache_stats():
    with _db_lock:
        conn = _db_conn()
        total = conn.execute('SELECT COUNT(*) FROM ws_cache').fetchone()[0]
        oldest = conn.execute('SELECT MIN(created_at) FROM ws_cache').fetchone()[0]
        newest = conn.execute('SELECT MAX(created_at) FROM ws_cache').fetchone()[0]
        total_size = conn.execute('SELECT SUM(content_size) FROM ws_cache').fetchone()[0] or 0
        entries = conn.execute(
            'SELECT id, query, title, url, created_at, content_size FROM ws_cache ORDER BY created_at DESC LIMIT 50'
        ).fetchall()
        conn.close()
    return {
        'total': total,
        'oldest': oldest,
        'newest': newest,
        'total_content_size': total_size,
        'entries': [dict(e) for e in entries],
    }


@app.route("/")

def index():
    return send_from_directory(ASSET_DIR, "index.html")


# ── WS CACHE ENDPOINTS ────────────────────────────────────────────────────────

@app.route('/api/ws-cache/clear', methods=['POST'])
def ws_cache_clear():
    _cache_clear()
    return jsonify({'ok': True})


@app.route('/api/ws-cache/stats', methods=['GET'])
def ws_cache_stats():
    return jsonify(_cache_stats())



# ── WEB SEARCH ────────────────────────────────────────────────────────────────

def _call_llm_simple(provider, model, prompt, api_key='', server_url='http://192.168.0.17:11434', temp=0.3, ctx=8192, timeout=90):
    """Non-streaming LLM call. Returns text response string."""
    if provider == 'ollama':
        server = server_url.rstrip('/')
        payload = {
            'model': model,
            'messages': [{'role': 'user', 'content': prompt}],
            'stream': False,
            'options': {'temperature': temp, 'num_ctx': ctx},
        }
        resp = requests.post(f'{server}/api/chat', json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json().get('message', {}).get('content', '')

    elif provider == 'openai':
        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
        }
        payload = {
            'model': model,
            'messages': [{'role': 'user', 'content': prompt}],
            'temperature': temp,
            'max_tokens': ctx,
            'stream': False,
        }
        resp = requests.post('https://api.openai.com/v1/chat/completions',
                             headers=headers, json=payload, timeout=timeout)
        resp.raise_for_status()
        return resp.json()['choices'][0]['message']['content']

    elif provider == 'gemini':
        payload = {
            'contents': [{'role': 'user', 'parts': [{'text': prompt}]}],
            'generationConfig': {'temperature': temp, 'maxOutputTokens': ctx},
        }
        url = (f'https://generativelanguage.googleapis.com/v1beta/models/'
               f'{model}:generateContent?key={api_key}')
        resp = requests.post(url, json=payload, timeout=timeout)
        resp.raise_for_status()
        candidates = resp.json().get('candidates', [])
        if candidates:
            parts = candidates[0].get('content', {}).get('parts', [])
            return ''.join(p.get('text', '') for p in parts)
        return ''

    elif provider == 'anthropic':
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json',
            'anthropic-version': '2023-06-01',
        }
        payload = {
            'model': model,
            'messages': [{'role': 'user', 'content': prompt}],
            'temperature': temp,
            'max_tokens': ctx,
        }
        resp = requests.post('https://api.anthropic.com/v1/messages',
                             headers=headers, json=payload, timeout=timeout)
        resp.raise_for_status()
        content = resp.json().get('content', [])
        return ''.join(c.get('text', '') for c in content if c.get('type') == 'text')

    else:
        raise ValueError(f'Unknown provider: {provider}')


def _search_ddg(query, max_results=5, region='wt-wt'):
    """Search DuckDuckGo. Returns list of {title, url, snippet}."""
    try:
        from ddgs import DDGS
    except ImportError:
        from duckduckgo_search import DDGS

    results = []
    with DDGS() as ddgs:
        for r in ddgs.text(query, region=region, safesearch='off', max_results=max_results):
            results.append({
                'title': r.get('title', ''),
                'url': r.get('href', ''),
                'snippet': r.get('body', ''),
            })
    return results


# ── YOUTUBE FETCH (yt-dlp) ────────────────────────────────────────────────
_RE_YOUTUBE = re.compile(
    r'(?:https?://)?(?:www\.|m\.)?'
    r'(?:youtube\.com/(?:watch\?v=|embed/|v/|shorts/|live/)'
    r'|youtu\.be/)'
    r'([a-zA-Z0-9_-]{11})'
)

def _is_youtube_url(url):
    """Check if a URL is a YouTube video page."""
    return bool(_RE_YOUTUBE.search(url))


def _youtube_fetch(url, max_size=30000):
    """Fetch YouTube video info + transcript via yt-dlp.
    Returns (text, 'youtube') or raises on failure.
    The text includes: title, uploader, description, and auto-generated subtitles.
    """
    import subprocess as _sp

    # Extract video ID
    m = _RE_YOUTUBE.search(url)
    if not m:
        raise ValueError(f"Could not extract YouTube video ID from: {url}")
    video_id = m.group(1)

    # Fetch video metadata via --print (no --dump-json to avoid conflict)
    cmd = [
        'yt-dlp',
        '--print', '%(title)s|||%(uploader)s|||%(description)s|||%(webpage_url)s',
        '--skip-download',
        '--add-headers', 'User-Agent:Mozilla/5.0',
        url,
    ]
    result = _sp.run(cmd, capture_output=True, text=True, timeout=60)
    stdout = result.stdout.strip()
    # yt-dlp exits non-zero for warnings (nsig, formats) but still outputs data
    if not stdout:
        raise RuntimeError(f"yt-dlp failed: {result.stderr[:500]}")

    # Parse metadata line
    lines = stdout.split('\n')
    meta_line = lines[0]
    parts = meta_line.split('|||')
    title = parts[0] if len(parts) > 0 else ''
    uploader = parts[1] if len(parts) > 1 else ''
    description = parts[2] if len(parts) > 2 else ''
    webpage_url = parts[3] if len(parts) > 3 else url

    # Build content
    content_parts = [
        "=== YOUTUBE VIDEO ===",
        f"Title: {title}",
        f"Uploader: {uploader}",
        f"URL: {webpage_url}",
        "",
    ]
    if description:
        desc = description[:5000]
        content_parts.append(f"Description:\n{desc}")
        content_parts.append("")

    # Extract subtitles via yt-dlp (download to tmp, parse back)
    try:
        import glob as _glob
        sub_cmd = [
            'yt-dlp', '--write-auto-subs', '--sub-langs', 'ro,en,-live_chat',
            '--skip-download', '--convert-subs', 'srt',
            '--output', f'/tmp/_ws_yt_{video_id}',
            '--add-headers', 'User-Agent:Mozilla/5.0',
            url,
        ]
        sub_result = _sp.run(sub_cmd, capture_output=True, text=True, timeout=20)
        # 429 = rate limited — skip subtitles silently
        if '429' not in sub_result.stderr:
            sub_files = _glob.glob(f'/tmp/_ws_yt_{video_id}.*.srt') + \
                        _glob.glob(f'/tmp/_ws_yt_{video_id}.*.vtt')
            if sub_files:
                sub_lines = []
                for sf in sorted(sub_files):
                    with open(sf, 'r', errors='replace') as f:
                        for line in f:
                            line = line.strip()
                            if line and '-->' not in line and not line.isdigit():
                                sub_lines.append(line)
                    os.remove(sf)
                if sub_lines:
                    content_parts.append(f"Transcript ({len(sub_lines)} lines):")
                    content_parts.append('\n'.join(sub_lines)[:20000])
    except Exception:
        pass

    full_text = '\n'.join(content_parts)
    return full_text[:max_size], 'youtube'


# ── BROWSER FETCH (Playwright headless) ───────────────────────────────────
def _browser_fetch(url, max_size=30000, timeout_sec=20):
    """Fetch a page using Playwright headless Chromium.
    Returns (text, 'browser') or raises on failure.
    Optional dependency — requires: pip install playwright && python -m playwright install chromium
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise RuntimeError("Playwright not installed. Run: pip install playwright && python -m playwright install chromium")

    text = ''
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=[
                '--no-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--disable-setuid-sandbox',
            ],
        )
        context = browser.new_context(
            user_agent=(
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            ),
            locale='ro-RO',
        )
        page = context.new_page()
        try:
            page.goto(url, wait_until='domcontentloaded', timeout=timeout_sec * 1000)
            page.wait_for_timeout(2000)
            try:
                page.wait_for_selector('body', timeout=5000)
            except Exception:
                pass
            text = page.evaluate('''() => {
                for (const el of document.querySelectorAll('script, style, nav, footer, header, aside, svg, [role="navigation"]')) {
                    el.remove();
                }
                return document.body ? document.body.innerText : '';
            }''') or ''
        except Exception as e:
            raise RuntimeError(f"Playwright navigation failed: {e}")
        finally:
            browser.close()

    if not text.strip():
        raise RuntimeError("Playwright returned empty content")

    lines = [l.strip() for l in text.split('\n') if l.strip()]
    text = '\n'.join(lines)
    return text[:max_size], 'browser'


def _fetch_page_content(url, max_size=30000):
    """Fetch URL and extract text. Returns (text, content_type_str).

    Routing logic:
      - YouTube (youtube.com, youtu.be)  → _youtube_fetch() via yt-dlp
      - All other URLs:
          1. HTTP fetch (trafilatura → BS4 → regex)
          2. If content too short (<500 chars or JS placeholder) → Playwright headless
    """
    import re as _re

    # ── YouTube route ──
    if _is_youtube_url(url):
        try:
            text, _ = _youtube_fetch(url, max_size=max_size)
            return text, 'youtube'
        except Exception as e:
            raise RuntimeError(f"YouTube fetch failed: {e}")

    # ── Standard HTTP fetch ──
    headers = {
        'User-Agent': ('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 '
                       '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
    }
    resp = requests.get(url, headers=headers, timeout=30, allow_redirects=True)
    resp.raise_for_status()
    content_type = resp.headers.get('Content-Type', '').lower()

    text = ''
    method = 'unknown'

    if 'text/html' in content_type or not content_type:
        from bs4 import BeautifulSoup

        # ── Pass 1: trafilatura (precision mode off = extract more) ──
        _JUNK_PATTERNS = _re.compile(
            r'(confidențialitate|privacy policy|cookie policy|gdpr|'
            r'navigate forward to interact|navigate backward|keyboard shortcuts|'
            r'press the question mark|prelucrare.*date personale)',
            _re.I
        )
        try:
            import trafilatura
            from trafilatura.settings import use_config
            _tcfg = use_config()
            _tcfg.set('DEFAULT', 'MIN_EXTRACTED_SIZE', '50')
            _tcfg.set('DEFAULT', 'MIN_DUPLCHECK_SIZE', '100')
            _traf = trafilatura.extract(
                resp.text,
                include_links=False,
                include_tables=True,
                include_comments=False,
                favor_precision=False,
                config=_tcfg,
            )
            if _traf and len(_traf.strip()) > 100:
                # Reject if content looks like privacy policy or UI navigation noise
                _sample = _traf[:300].lower()
                if not _JUNK_PATTERNS.search(_sample):
                    text = _traf
                    method = 'trafilatura'
        except Exception:
            pass

        # ── Pass 2: BeautifulSoup targeted on semantic content areas ──
        if not text or len(text.strip()) <= 100:
            try:
                soup = BeautifulSoup(resp.text, 'html.parser')
                # Remove noise elements
                for el in soup.find_all(['script', 'style', 'nav', 'footer',
                                         'header', 'aside', 'form', 'noscript',
                                         'iframe', 'svg', 'button']):
                    el.decompose()
                # Remove cookie/privacy policy sections by common class/id names
                for el in soup.find_all(True, {'id': _re.compile(r'cookie|gdpr|consent|privacy|modal|popup', _re.I)}):
                    el.decompose()
                for el in soup.find_all(True, {'class': _re.compile(r'cookie|gdpr|consent|privacy|modal|popup|overlay', _re.I)}):
                    el.decompose()
                # Prefer semantic content areas
                main = (soup.find('main') or soup.find('article') or
                        soup.find(attrs={'role': 'main'}) or
                        soup.find('div', {'id': _re.compile(r'content|main|body', _re.I)}) or
                        soup.find('div', {'class': _re.compile(r'content|main|body|post|entry', _re.I)}) or
                        soup.body or soup)
                # Extract headings + paragraphs + list items for structure
                parts = []
                for tag in main.find_all(['h1','h2','h3','h4','p','li','td','th','span'], limit=300):
                    t = tag.get_text(separator=' ', strip=True)
                    if len(t) > 20:
                        parts.append(t)
                text = '\n'.join(parts)
                text = _re.sub(r'\n{3,}', '\n\n', text)
                if len(text.strip()) > 100:
                    method = 'bs4'
            except Exception:
                pass

        # ── Pass 3: last resort regex strip ──
        if not text or len(text.strip()) <= 100:
            text = _re.sub(r'<[^>]+>', '', resp.text)
            text = _re.sub(r'\s+', ' ', text).strip()
            method = 'regex'

        if text:
            text = text[:max_size]

    elif 'text/plain' in content_type:
        text = resp.text[:max_size]
        method = 'text'

    else:
        text = _re.sub(r'<[^>]+>', '', resp.text)
        text = _re.sub(r'\s+', ' ', text).strip()
        text = text[:max_size]
        method = 'unknown'

    text = text or ''

    # ── Detect JS skeleton → try Playwright ──
    # Trigger on explicit JS markers OR if content is suspiciously short (<400 chars).
    # Very short content after trafilatura+BS4 almost always means a JS-rendered app shell.
    # Exception: YouTube/social URLs are handled before reaching here.
    stripped = text.strip()
    js_markers = (
        len(stripped) < 400
        or 'enable javascript' in stripped.lower()
        or 'enable js' in stripped.lower()
        or (stripped.lower()[:80].count('loading') > 0 and len(stripped) < 120)
    )

    if js_markers:
        # Fallback to Playwright headless (optional dependency)
        try:
            browser_text, _ = _browser_fetch(url, max_size=max_size)
            return browser_text, 'browser'
        except Exception:
            return text, f'{method}_skeleton'

    return text, method


_DEFAULT_WS_OPT_PROMPT = (
    "Your task is to formulate the best search query for DuckDuckGo.\n\n"
    "Today's date: {date}\n"
    "User's reason: {reason}\n"
    "User's query: {query}\n\n"
    "Instructions:\n"
    "1. Optimize the query for DuckDuckGo search (add relevant technical terms).\n"
    "2. ALWAYS write the query in English, regardless of input language.\n"
    "3. Keep it concise (max 10 words).\n"
    "4. Replace any outdated years in the query with the current year from Today's date (e.g. if today is 2026, replace 2024/2025 with 2026).\n"
    "5. DO NOT use search operators like site:, inurl:, intitle:, filetype:\n"
    "6. Return ONLY the optimized search query, nothing else. No quotes, no explanation."
)

_DEFAULT_WS_RANK_PROMPT = (
    "Evaluate these search results and rank them by relevance.\n\n"
    "REASON the user needs this information:\n{reason}\n\n"
    "SEARCH QUERY: {query}\n\n"
    "SEARCH RESULTS:\n{results}\n"
    "Instructions:\n"
    "1. Rank the results by relevance to the REASON (most relevant first).\n"
    "2. Prefer official sources: documentation, changelogs, official blogs, GitHub repos of the project.\n"
    "3. Exclude obviously irrelevant results (ads, unrelated topics, wrong language communities).\n"
    "4. Return ONLY the numbers of the top results in order, comma-separated.\n"
    "   Example: 2,1,4\n"
    "5. Maximum {max_fetch} results."
)

_DEFAULT_WS_REL_PROMPT = (
    "Evaluate if this web page is a relevant SOURCE for the user's needs.\n\n"
    "REASON: {reason}\n"
    "SEARCH QUERY: {query}\n\n"
    "PAGE TITLE: {title}\n"
    "PAGE URL: {url}\n"
    "PAGE CONTENT (sample):\n{content}\n\n"
    "Answer YES or NO.\n"
    "- Answer YES if the page title, URL or content mentions the topic, product, person or event from the search query "
    "— this includes reviews, comparisons, tutorials, news articles, product pages, YouTube videos, forum posts.\n"
    "- Answer NO ONLY if the page is clearly about a completely different topic, product or person.\n"
    "Be generous: when in doubt, answer YES.\n"
    "One line: YES or NO followed by a brief reason."
)

_DEFAULT_WS_OVERVIEW_PROMPT = (
    "Read the following web page content and provide a brief structured overview.\n\n"
    "CONTENT:\n{content}\n\n"
    "Provide:\n"
    "- Page type (e.g. official docs, changelog, blog post, forum, GitHub repo, tutorial)\n"
    "- Main topics covered (2-4 bullet points)\n"
    "- Key details present: versions, dates, commands, names (if any)\n"
    "Be concise — maximum 8 bullet points total."
)

_DEFAULT_WS_SUMM_PROMPT = (
    "You are extracting useful information from a web page. Today's date is {date}.\n\n"
    "RESEARCH GOAL: {reason}\n"
    "SEARCH QUERY: {query}\n"
    "SOURCE: {source_title} ({source_url})\n\n"
    "PAGE CONTENT:\n{content}\n\n"
    "Instructions:\n"
    "1. Extract and summarize ALL useful information present in the page content above.\n"
    "2. Prioritize information relevant to the RESEARCH GOAL, but include other notable facts too.\n"
    "3. Preserve specific details: names, prices, dates, URLs, phone numbers, addresses, ratings, specs.\n"
    "4. If the content is clearly outdated relative to today ({date}), mention it.\n"
    "5. Respond in the same language as the RESEARCH GOAL.\n"
    "6. Start directly with the extracted information — no meta-commentary.\n"
    "7. IMPORTANT: Always write at least 2-3 sentences. If the page has ANY useful content, summarize it."
)

_DEFAULT_WS_ADAPTIVE_PROMPT = (
    "You are a web search planner. Given a research query, decide how many sub-queries and how many result sources are needed.\n\n"
    "Today's date: {date}\n"
    "REASON / RESEARCH GOAL: {reason}\n"
    "ORIGINAL QUERY: {query}\n\n"
    "Constraints set by user (do NOT exceed these):\n"
    "  max_queries_limit: {max_queries_limit}\n"
    "  max_sources_limit: {max_sources_limit}\n\n"
    "Rules:\n"
    "- Simple factual questions (one clear answer): max_queries=1, max_sources=1\n"
    "- Moderate questions (comparison, how-to, recent event): max_queries=1-2, max_sources=2-3\n"
    "- Complex research (multiple aspects, pros/cons, synthesis needed): max_queries=3-4, max_sources=3-5\n"
    "- Never exceed the user's limits above.\n\n"
    "Respond ONLY with a valid JSON object, no explanation, no markdown:\n"
    '{"max_queries": <int>, "max_sources": <int>, "reason": "<one short sentence why>"}'
)

_DEFAULT_WS_DECOMP_PROMPT = (
    "You are a search query decomposer. Your task is to break down a complex research question into {max_queries} independent, specific search queries that together cover all important aspects of the topic.\n\n"
    "Today's date: {date}\n"
    "REASON / RESEARCH GOAL: {reason}\n"
    "ORIGINAL QUERY: {query}\n\n"
    "Instructions:\n"
    "1. Generate between 2 and {max_queries} search queries, each targeting a DIFFERENT angle of the topic.\n"
    "2. Each query must be self-contained and specific enough for a web search engine.\n"
    "3. Avoid redundant or overlapping queries.\n"
    "4. If the original query is already specific enough and does not benefit from decomposition, output only 1 query (the original or an optimized version).\n"
    "5. IMPORTANT: Replace any outdated years in the queries with the current year from Today's date. "
    "For example, if Today's date is 2026-05-27 and the original query contains '2024' or '2025', replace them with '2026'.\n"
    "6. Output ONLY the queries, one per line, with no numbering, no explanations, no extra text.\n\n"
    "OUTPUT (one query per line):"
)

_DEFAULT_WS_MULTISYNTH_PROMPT = (
    "You are synthesizing web research results from multiple searches into a single coherent answer.\n\n"
    "Today's date: {date}\n"
    "RESEARCH GOAL: {reason}\n"
    "ORIGINAL QUERY: {query}\n\n"
    "RESULTS FROM MULTIPLE SEARCHES:\n{results}\n\n"
    "Instructions:\n"
    "1. Synthesize all the above search results into one comprehensive, well-structured answer.\n"
    "2. Eliminate redundancy — if multiple sources say the same thing, state it once.\n"
    "3. Preserve all specific details: numbers, dates, statistics, names, URLs.\n"
    "4. Organize by topic/theme, not by search query.\n"
    "5. If sources contradict each other, note the discrepancy explicitly.\n"
    "6. Respond in the same language as the RESEARCH GOAL.\n"
    "7. Start directly with the content — no meta-commentary about the search process."
)


def _run_single_query_pipeline(query, reason, original_query, config, chunk, _today, _re, live_stats=None):
    """Rulează pipeline-ul complet (search→rank→fetch→summarize) pentru un singur query.
    Yield-uiește chunk-uri bytes (log) și ca ultim element yielduiește lista summaries.
    """
    provider    = config.get('provider', 'ollama')
    model       = config.get('model', '')
    api_key     = config.get('apiKey', '')
    server_url  = config.get('serverUrl', 'http://localhost:11434')
    max_results       = int(config.get('maxResults', 5))
    max_fetch         = int(config.get('maxFetch', 3))
    max_page          = int(config.get('maxPageSize', 30000))
    brief_thr         = int(config.get('briefThreshold', 3000))
    region            = config.get('region', 'wt-wt')
    max_store_results = int(config.get('maxStoreResults', 1))
    overview_enabled  = bool(config.get('overviewEnabled', True))
    rank_prompt_tpl   = config.get('rankPrompt', '')     or _DEFAULT_WS_RANK_PROMPT
    rel_prompt_tpl    = config.get('relPrompt', '')      or _DEFAULT_WS_REL_PROMPT
    overview_prompt_tpl = config.get('overviewPrompt', '') or _DEFAULT_WS_OVERVIEW_PROMPT
    summ_prompt_tpl   = config.get('summPrompt', '')     or _DEFAULT_WS_SUMM_PROMPT
    cache_ttl         = int(config.get('cacheTTL', 7200))
    ctx_size          = int(config.get('contextSize', 8192))

    # Search
    yield chunk(log=f'  → DDG search: "{query}"')
    try:
        results = _search_ddg(query, max_results=max_results, region=region)
    except Exception as e:
        yield chunk(log=f'  Search failed: {e}')
        results = []

    if not results:
        yield chunk(log=f'  No results for "{query}"')
        return

    yield chunk(log=f'  Found {len(results)} results')

    # Rank
    ranked_indices = list(range(min(max_fetch, len(results))))
    try:
        results_text = ''
        for i, r in enumerate(results, 1):
            results_text += f'#{i}. {r["title"]}\n   {r["url"]}\n   {r["snippet"]}\n\n'
        rank_prompt = (
            rank_prompt_tpl
            .replace('{reason}', reason)
            .replace('{query}', query)
            .replace('{results}', results_text)
            .replace('{max_fetch}', str(max_fetch))
        )
        rank_resp = _call_llm_simple(provider, model, rank_prompt,
                                     api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
        ranked = []
        for num in _re.findall(r'\d+', rank_resp):
            idx = int(num) - 1
            if 0 <= idx < len(results) and idx not in ranked:
                ranked.append(idx)
        if ranked:
            ranked_indices = ranked[:max_fetch]
    except Exception as e:
        yield chunk(log=f'  Ranking failed ({e})')

    # Fetch + relevance + summarize
    summaries = []
    _SKIP_DOMAINS = ('instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'tiktok.com', 'linkedin.com')

    for idx in ranked_indices:
        if len(summaries) >= max_store_results:
            break
        r = results[idx]
        url   = r['url']
        title = r['title']

        # Skip login-walled social media — always inaccessible
        if any(d in url for d in _SKIP_DOMAINS):
            yield chunk(log=f'  Skip (social media): {url}')
            continue

        # Cache check
        if cache_ttl > 0:
            url_cached = _cache_get_by_url(url, cache_ttl)
            if url_cached and url_cached['full_content']:
                yield chunk(log=f'  Cache hit: {title}')
                content = url_cached['full_content']
                title   = url_cached['title'] or title
                # summarize cached content
                summ_prompt = (
                    summ_prompt_tpl
                    .replace('{date}', _today)
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                    .replace('{source_title}', title)
                    .replace('{source_url}', url)
                    .replace('{content}', content[:max_page])
                )
                try:
                    summary = _call_llm_simple(provider, model, summ_prompt,
                                               api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
                except Exception:
                    summary = ''
                if len(summary) < 50:
                    # For YouTube: use title + content snippet as minimal summary rather than skip
                    if fetch_method == 'youtube' and content.strip():
                        summary = content.strip()[:500]
                    else:
                        yield chunk(log=f'  Summary too short ({len(summary)} chars), skipping')
                        if live_stats is not None:
                            live_stats['sources_skip'] += 1
                            yield chunk(stats=dict(live_stats))
                        continue
                summaries.append({'summary': summary, 'title': title, 'url': url, 'content_size': len(content)})
                if live_stats is not None:
                    live_stats['sources_ok'] += 1
                    live_stats['chars'] += len(content)
                    yield chunk(stats=dict(live_stats))
                continue

        yield chunk(log=f'  Fetching: {url}')
        try:
            content, ctype = _fetch_page_content(url, max_size=max_page)
            if len(content.strip()) < 100:
                yield chunk(log='  Content too short, skipping')
                continue

            # Overview
            overview_text = content[:3000]
            if overview_enabled:
                try:
                    ov_prompt = overview_prompt_tpl.replace('{content}', content)
                    overview_text = _call_llm_simple(provider, model, ov_prompt,
                                                     api_key=api_key, server_url=server_url,
                                                     temp=0.1, ctx=ctx_size).strip()
                except Exception as e:
                    yield chunk(log=f'  Overview failed ({e})')

            # Relevance — fast keyword pre-check before LLM call
            # If enough query keywords appear in title+url, accept immediately
            _STOPWORDS = {'the','and','for','are','was','how','use','using','with','from',
                          'manual','utilizare','montare','instalare','review','youtube','despre'}
            _q_words = [w for w in _re.split(r'\W+', query.lower()) if len(w) > 2 and w not in _STOPWORDS]
            _haystack = (title + ' ' + url).lower()
            _kw_hits = sum(1 for w in _q_words if w in _haystack)
            _kw_ratio = _kw_hits / max(len(_q_words), 1)
            if _kw_ratio >= 0.3:
                is_relevant = True
                yield chunk(log=f'  Relevance: YES (keyword match {_kw_hits}/{len(_q_words)}) — {title}')
            else:
                rel_prompt = (
                    rel_prompt_tpl
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                    .replace('{title}', title)
                    .replace('{url}', url)
                    .replace('{content}', overview_text)
                )
                try:
                    rel_resp = _call_llm_simple(provider, model, rel_prompt,
                                                api_key=api_key, server_url=server_url, temp=0.1, ctx=ctx_size).strip()
                    is_relevant = rel_resp.upper().startswith('YES')
                    yield chunk(log=f'  Relevance: {"YES" if is_relevant else "NO"} — {title}')
                except Exception as e:
                    yield chunk(log=f'  Relevance check failed ({e}), accepting')
                    is_relevant = True

            if not is_relevant:
                if live_stats is not None:
                    live_stats['sources_skip'] += 1
                    yield chunk(stats=dict(live_stats))
                continue

            # Summarize
            summ_prompt = (
                summ_prompt_tpl
                .replace('{date}', _today)
                .replace('{reason}', reason)
                .replace('{query}', query)
                .replace('{source_title}', title)
                .replace('{source_url}', url)
                .replace('{content}', content[:max_page])
            )
            try:
                summary = _call_llm_simple(provider, model, summ_prompt,
                                           api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
            except Exception as e:
                summary = ''
                yield chunk(log=f'  Summary failed ({e})')

            if len(summary) < 50:
                if ctype == 'youtube' and content.strip():
                    summary = content.strip()[:500]
                else:
                    yield chunk(log=f'  Summary too short ({len(summary)} chars), skipping')
                    if live_stats is not None:
                        live_stats['sources_skip'] += 1
                        yield chunk(stats=dict(live_stats))
                    continue

            yield chunk(log=f'  Summary: {title} ({len(summary)} chars)')
            _cache_store(hashlib.sha256(query.lower().strip().encode()).hexdigest(), query, reason, url, title, summary, content, len(content), success=1)
            summaries.append({'summary': summary, 'title': title, 'url': url, 'content_size': len(content)})
            if live_stats is not None:
                live_stats['sources_ok'] += 1
                live_stats['chars'] += len(content)
                yield chunk(stats=dict(live_stats))

        except Exception as e:
            yield chunk(log=f'  Fetch failed {url}: {e}')
            if live_stats is not None:
                live_stats['sources_err'] += 1
                yield chunk(stats=dict(live_stats))

    # Ultimul element yielded este lista de summaries (nu bytes)
    yield summaries


def _stream_websearch(data):
    """Generator that streams NDJSON chunks for web search progress."""
    import re as _re
    import time as _time

    reason = data.get('reason', '')
    query  = data.get('query', '')
    config = data.get('config', {})

    provider    = config.get('provider', 'ollama')
    model       = config.get('model', '')
    api_key     = config.get('apiKey', '')
    server_url  = config.get('serverUrl', 'http://localhost:11434')
    cache_ttl         = int(config.get('cacheTTL', 7200))
    ctx_size          = int(config.get('contextSize', 8192))
    brief_thr         = int(config.get('briefThreshold', 3000))
    opt_prompt_tpl    = config.get('optPrompt', '')       or _DEFAULT_WS_OPT_PROMPT
    decomp_prompt_tpl = config.get('decompPrompt', '')    or _DEFAULT_WS_DECOMP_PROMPT
    multisynth_prompt_tpl = config.get('multiSynthPrompt', '') or _DEFAULT_WS_MULTISYNTH_PROMPT
    multi_query_enabled = bool(config.get('multiQueryEnabled', False))
    max_queries       = max(1, min(4, int(config.get('maxQueries', 3))))
    max_store_results = max(1, int(config.get('maxStoreResults', 1)))
    adaptive_enabled  = bool(config.get('wsAdaptive', False))
    adaptive_prompt_tpl = config.get('adaptivePrompt', '') or _DEFAULT_WS_ADAPTIVE_PROMPT

    _live_stats = {'sources_ok': 0, 'sources_skip': 0, 'sources_err': 0, 'chars': 0, 'queries_done': 0}

    def chunk(step=None, step_status=None, log=None, done=False, result=None, stats=None):
        obj = {'done': done}
        if step is not None:
            obj['step'] = step
        if step_status:
            obj['stepStatus'] = step_status
        if log:
            obj['log'] = log
        if result is not None:
            obj['result'] = result
        if stats is not None:
            obj['stats'] = stats
        return (json.dumps(obj, ensure_ascii=False) + '\n').encode('utf-8')

    def stats_chunk():
        return chunk(stats=dict(_live_stats))

    try:
        import datetime as _dt
        _today = _dt.date.today().isoformat()

        # ── STEP 0: Optimize / Decompose query ──
        yield chunk(step=0, step_status='active', log=f'Reason: {reason}')
        yield chunk(log=f'Original query: {query}')

        # Cache check (whole query)
        cache_key = query.lower().strip()
        if cache_ttl > 0:
            cached_row = _cache_get(cache_key, cache_ttl)
            if cached_row:
                age = int(time.time() - cached_row['created_at'])
                cached_result = {
                    'success': bool(cached_row['success']),
                    'summary': cached_row['summary'],
                    'sourceUrl': cached_row['url'],
                    'sourceTitle': cached_row['title'],
                    'contentSize': cached_row['content_size'],
                }
                yield chunk(log=f'Cache hit (age {age}s): {(cached_row["title"] or "")}')
                yield chunk(step=0, step_status='done')
                yield chunk(step=1, step_status='done')
                yield chunk(step=2, step_status='done')
                yield chunk(step=3, step_status='done')
                yield chunk(step=4, step_status='done', log='Done (cached).')
                yield chunk(done=True, result=cached_result)
                return

        # ── Adaptive planning (LLM decides max_queries / max_store_results) ──
        if adaptive_enabled:
            try:
                adap_prompt = (
                    adaptive_prompt_tpl
                    .replace('{date}', _today)
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                    .replace('{max_queries_limit}', str(max_queries))
                    .replace('{max_sources_limit}', str(max_store_results))
                )
                adap_raw = _call_llm_simple(provider, model, adap_prompt,
                                            api_key=api_key, server_url=server_url, temp=0.0, ctx=512).strip()
                # extract JSON even if model wraps it in markdown
                import re as _re2
                m = _re2.search(r'\{[^{}]+\}', adap_raw, _re2.DOTALL)
                if m:
                    adap = json.loads(m.group())
                    new_mq = max(1, min(max_queries, int(adap.get('max_queries', max_queries))))
                    new_ms = max(1, min(max_store_results, int(adap.get('max_sources', max_store_results))))
                    adap_reason = adap.get('reason', '')
                    yield chunk(log=f'Adaptive plan: sub-queries={new_mq} (was {max_queries}), sources={new_ms} (was {max_store_results}). {adap_reason}')
                    max_queries = new_mq
                    max_store_results = new_ms
                    config = dict(config, maxStoreResults=new_ms, maxQueries=new_mq)
                else:
                    yield chunk(log=f'Adaptive planning: could not parse LLM response, using defaults.')
            except Exception as e:
                yield chunk(log=f'Adaptive planning skipped: {e}')

        # Decompose (multi-query) sau optimizare simplă
        sub_queries = []
        if multi_query_enabled:
            yield chunk(log=f'Multi-query mode: decomposing into max {max_queries} sub-queries...')
            try:
                decomp_prompt = (
                    decomp_prompt_tpl
                    .replace('{date}', _today)
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                    .replace('{max_queries}', str(max_queries))
                )
                decomp_resp = _call_llm_simple(provider, model, decomp_prompt,
                                               api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
                lines = [l.strip().strip('"\'- ') for l in decomp_resp.splitlines() if l.strip()]
                sub_queries = [l for l in lines if 3 < len(l) < 200][:max_queries]
                yield chunk(log=f'Decomposed into {len(sub_queries)} queries:')
                for i, q in enumerate(sub_queries, 1):
                    yield chunk(log=f'  Q{i}: {q}')
            except Exception as e:
                yield chunk(log=f'Decomposition failed ({e}), falling back to single query')

        if not sub_queries:
            # Optimizare simplă
            optimized = query
            try:
                opt_prompt = (
                    opt_prompt_tpl
                    .replace('{date}', _today)
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                )
                optimized = _call_llm_simple(provider, model, opt_prompt,
                                             api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
                optimized = optimized.strip('"\'').strip()
                optimized = _re.sub(r'\b(site|inurl|intitle|filetype):\S+\s*', '', optimized).strip()
                if len(optimized) > 150 or len(optimized) < 3:
                    optimized = query
                yield chunk(log=f'Optimized query: {optimized}')
            except Exception as e:
                yield chunk(log=f'Optimization failed ({e}), using original')
            sub_queries = [optimized]

        yield chunk(step=0, step_status='done')

        # ── STEPS 1-4: Pipeline per sub-query ──
        yield chunk(step=1, step_status='active')
        yield chunk(step=2, step_status='active')
        yield chunk(step=3, step_status='active')
        yield chunk(step=4, step_status='active', log=f'Running pipeline for {len(sub_queries)} query/queries...')

        all_summaries = []   # [{summary, title, url, content_size, query}]
        seen_urls = set()

        for qi, sq in enumerate(sub_queries, 1):
            if len(sub_queries) > 1:
                yield chunk(log=f'─── Query {qi}/{len(sub_queries)}: "{sq}" ───')
            gen = _run_single_query_pipeline(sq, reason, query, config, chunk, _today, _re, live_stats=_live_stats)
            summaries = []
            for item in gen:
                if isinstance(item, bytes):
                    yield item   # log/stats chunk
                elif isinstance(item, list):
                    summaries = item  # ultimul element = lista summaries

            _live_stats['queries_done'] = qi
            yield stats_chunk()

            # Deduplicare URL între query-uri
            for s in (summaries or []):
                if s['url'] not in seen_urls:
                    seen_urls.add(s['url'])
                    s['query'] = sq
                    all_summaries.append(s)

        yield chunk(step=1, step_status='done')
        yield chunk(step=2, step_status='done')
        yield chunk(step=3, step_status='done')

        if not all_summaries:
            fallback = (
                f'--- WEB SEARCH PARTIAL RESULT ---\n'
                f'Query: {query}\n'
                f'Note: Search found results but no relevant page could be fetched.\n'
                f'--- END WEB SEARCH ---'
            )
            fallback_obj = {'success': True, 'summary': fallback, 'sourceUrl': None, 'sourceTitle': None, 'contentSize': 0, 'sourceCount': 0}
            yield chunk(step=4, step_status='done', log='No relevant pages found.')
            yield chunk(done=True, result=fallback_obj)
            return

        # ── Formatare / sinteză finală ──
        if len(all_summaries) == 1 and len(sub_queries) == 1:
            # Rezultat clasic single-source
            s = all_summaries[0]
            formatted = (
                f'--- WEB SEARCH RESULT ---\n'
                f'Query: {query}\n'
                f'Source: {s["title"]}\nURL: {s["url"]}\n\n'
                f'{s["summary"]}\n'
                f'--- END WEB SEARCH ---'
            )
        elif len(sub_queries) == 1:
            # Multiple surse, single query — format clasic multi-source
            parts = [f'--- WEB SEARCH RESULT ---\nQuery: {query}\nSources found: {len(all_summaries)}\n']
            for i, s in enumerate(all_summaries, 1):
                parts.append(f'\n--- SOURCE {i}: {s["title"]} ---\nURL: {s["url"]}\n\n{s["summary"]}\n')
            parts.append('\n--- END WEB SEARCH ---')
            formatted = ''.join(parts)
        else:
            # Multi-query: sinteză LLM
            yield chunk(log=f'Synthesizing {len(all_summaries)} results from {len(sub_queries)} queries...')
            raw_results = ''
            for i, s in enumerate(all_summaries, 1):
                raw_results += f'--- Result {i} (query: "{s["query"]}") ---\nSource: {s["title"]}\nURL: {s["url"]}\n\n{s["summary"]}\n\n'
            try:
                synth_prompt = (
                    multisynth_prompt_tpl
                    .replace('{date}', _today)
                    .replace('{reason}', reason)
                    .replace('{query}', query)
                    .replace('{results}', raw_results)
                )
                synthesis = _call_llm_simple(provider, model, synth_prompt,
                                             api_key=api_key, server_url=server_url, temp=0.3, ctx=ctx_size).strip()
                yield chunk(log=f'Synthesis generated ({len(synthesis)} chars)')
            except Exception as e:
                yield chunk(log=f'Synthesis failed ({e}), using concatenated summaries')
                synthesis = raw_results

            parts = [f'--- WEB SEARCH RESULT (Multi-Query) ---\n']
            parts.append(f'Original query: {query}\n')
            parts.append(f'Sub-queries used: {len(sub_queries)}\n')
            parts.append(f'Sources analyzed: {len(all_summaries)}\n\n')
            parts.append(synthesis)
            parts.append('\n\n--- SOURCES ---\n')
            for i, s in enumerate(all_summaries, 1):
                parts.append(f'{i}. {s["title"]}\n   {s["url"]}\n')
            parts.append('--- END WEB SEARCH ---')
            formatted = ''.join(parts)

        total_size = sum(s['content_size'] for s in all_summaries)
        primary = all_summaries[0]
        result_obj = {
            'success': True,
            'summary': formatted,
            'sourceUrl': primary['url'],
            'sourceTitle': primary['title'],
            'contentSize': total_size,
            'sourceCount': len(all_summaries),
            'subQueryCount': len(sub_queries),
            'sources': [{'url': s['url'], 'title': s['title']} for s in all_summaries],
        }
        _cache_store(cache_key, query, reason, primary['url'], primary['title'], formatted,
                     None, total_size, success=1)
        yield chunk(step=4, step_status='done', log=f'Done. {len(all_summaries)} surse, {len(sub_queries)} query/queries.')
        yield chunk(done=True, result=result_obj)

    except Exception as e:
        import traceback
        traceback.print_exc()
        yield chunk(done=True, result={'success': False, 'summary': f'Web search error: {e}'})


@app.route('/api/websearch', methods=['POST'])
def websearch():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Body JSON invalid'}), 400
    return Response(_stream_websearch(data), content_type='application/x-ndjson')


# ── WEB SEARCH BACKGROUND TASKS ───────────────────────────────────────────────
_ws_tasks = {}       # {task_id: {'status': 'running'|'done'|'error', 'chunks': [...], 'result': None, 'lock': threading.Lock(), 'event': threading.Event()}}
_ws_tasks_lock = threading.Lock()


def _ws_task_runner(task_id, data):
    """Runs web search in background thread, stores all chunks."""
    task = _ws_tasks[task_id]
    try:
        for chunk in _stream_websearch(data):
            with task['lock']:
                task['chunks'].append(chunk)
            task['event'].set()
            task['event'].clear()
        with task['lock']:
            task['status'] = 'done'
    except Exception as e:
        err_chunk = (json.dumps({'done': True, 'result': {'success': False, 'summary': f'Error: {e}'}}, ensure_ascii=False) + '\n').encode('utf-8')
        with task['lock']:
            task['chunks'].append(err_chunk)
            task['status'] = 'error'
    task['event'].set()


@app.route('/api/websearch/start', methods=['POST'])
def websearch_start():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Body JSON invalid'}), 400
    task_id = _uuid.uuid4().hex
    task = {
        'status': 'running',
        'chunks': [],
        'result': None,
        'lock': threading.Lock(),
        'event': threading.Event(),
        'started_at': time.time(),
    }
    with _ws_tasks_lock:
        # Cleanup old done tasks (keep last 10)
        done_tasks = [(tid, t) for tid, t in _ws_tasks.items() if t['status'] != 'running']
        done_tasks.sort(key=lambda x: x[1].get('started_at', 0))
        for tid, _ in done_tasks[:-10]:
            del _ws_tasks[tid]
        _ws_tasks[task_id] = task
    thread = threading.Thread(target=_ws_task_runner, args=(task_id, data), daemon=True)
    thread.start()
    return jsonify({'task_id': task_id})


@app.route('/api/websearch/stream/<task_id>', methods=['GET'])
def websearch_stream(task_id):
    with _ws_tasks_lock:
        task = _ws_tasks.get(task_id)
    if not task:
        return jsonify({'error': 'Task not found'}), 404

    def generate():
        sent = 0
        while True:
            with task['lock']:
                chunks = task['chunks']
                new_chunks = chunks[sent:]
                is_done = task['status'] != 'running'
            for chunk in new_chunks:
                yield chunk
            sent += len(new_chunks)
            if is_done and sent >= len(task['chunks']):
                break
            task['event'].wait(timeout=2.0)

    return Response(generate(), content_type='application/x-ndjson')


@app.route('/api/websearch/task/<task_id>', methods=['DELETE'])
def websearch_task_delete(task_id):
    """Cancel and remove a websearch task completely."""
    with _ws_tasks_lock:
        task = _ws_tasks.pop(task_id, None)
    if task:
        task['status'] = 'error'
        task['event'].set()  # unblock any waiting stream
    return jsonify({'ok': True})


@app.route('/api/websearch/status', methods=['GET'])
def websearch_status_list():
    """Returns list of active/recent web search tasks."""
    now = time.time()
    with _ws_tasks_lock:
        # Mark stale running tasks as error (no heartbeat for >5 min = abandoned)
        for t in _ws_tasks.values():
            if t['status'] == 'running' and now - t.get('started_at', now) > 300:
                t['status'] = 'error'
        tasks = [{
            'task_id': tid,
            'status': t['status'],
            'chunks_count': len(t['chunks']),
            'started_at': t.get('started_at', 0),
        } for tid, t in _ws_tasks.items()]
    return jsonify({'tasks': tasks})



