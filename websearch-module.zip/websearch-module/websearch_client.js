// websearch_client.js
// Extras din index.html — logica client Web Search

function openWsModal() { document.getElementById('ws-modal').classList.add('open'); }
function closeWsModal() { document.getElementById('ws-modal').classList.remove('open'); }
function toggleWsFullscreen() {
  document.getElementById('ws-modal-box').classList.toggle('ws-fullscreen');
}
function clearWsLog() { document.getElementById('ws-log').innerHTML = ''; }
function copyWsLog() {
  const text = [...document.getElementById('ws-log').children].map(l => l.textContent).join('\n');
  navigator.clipboard.writeText(text).then(() => toast('Log copiat', 'ok'));
}

let _wsAbortCtrl = null;
let _wsServerRunning = false; // tracks server-side running state for chip glow

function _wsUpdateChip(active) {
  const chip = document.getElementById('ws-chip');
  const dot  = document.getElementById('ws-modal-dot');
  if (active) {
    chip.classList.add('active');
    if (dot) dot.style.background = '#22c55e';
  } else {
    chip.classList.remove('active');
    if (dot) dot.style.background = '';
  }
}

// Poll server every 2s to keep chip glow in sync with actual running state
setInterval(async () => {
  try {
    const r = await fetch('/api/websearch/status');
    const d = await r.json();
    const running = (d.tasks || []).some(t => t.status === 'running');
    if (running !== _wsServerRunning) {
      _wsServerRunning = running;
      _wsUpdateChip(running);
    }
  } catch(e) {}
}, 2000);

function stopWebSearch() {
  if (_wsAbortCtrl) {
    _wsAbortCtrl.abort();
    _wsAbortCtrl = null;
  }
  _wsAddLog('⏹ Oprit de utilizator.');
  document.getElementById('btn-ws-stop').style.display = 'none';
  document.getElementById('ws-modal-status').textContent = '⏹ Oprit';
  _wsUpdateChip(false);
}

function _wsResetModal() {
  for (let i = 0; i < 5; i++) {
    const el = document.getElementById('wss-' + i);
    el.className = 'ws-step';
    el.querySelector('.ws-step-icon').textContent = '⟳';
  }
  document.getElementById('ws-log').innerHTML = '';
  document.getElementById('ws-query-display').textContent = '';
  document.getElementById('ws-result-row').className = 'ws-result-row';
  document.getElementById('ws-result-row').innerHTML = '';
  document.getElementById('ws-stats-row').className = 'ws-stats-row';
  document.getElementById('ws-stats-row').innerHTML = '';
  document.getElementById('ws-modal-status').textContent = 'Inactiv';
  // chip glow managed exclusively by _wsUpdateChip() + polling interval
}

function _wsSetLiveStats(s) {
  const row = document.getElementById('ws-stats-row');
  row.className = 'ws-stats-row show';
  const chars = s.chars || 0;
  const size = chars >= 1000 ? (chars/1000).toFixed(1) + 'k' : chars;
  const tokens = Math.round(chars / 4);
  const tokStr = tokens >= 1000 ? (tokens/1000).toFixed(1) + 'k' : tokens;
  row.innerHTML =
    (s.queries_done   ? `<span class="ws-stat">Queries: <span class="ws-stat-val">${s.queries_done}</span></span>` : '') +
    `<span class="ws-stat">✓ Surse: <span class="ws-stat-val" style="color:var(--green)">${s.sources_ok}</span></span>` +
    (s.sources_skip   ? `<span class="ws-stat">⊘ Ignorate: <span class="ws-stat-val">${s.sources_skip}</span></span>` : '') +
    (s.sources_err    ? `<span class="ws-stat">✗ Erori: <span class="ws-stat-val" style="color:var(--red)">${s.sources_err}</span></span>` : '') +
    (chars            ? `<span class="ws-stat">Conținut: <span class="ws-stat-val">${size} chars / ~${tokStr} tok</span></span>` : '');
}

function _wsSetStep(i, status) {
  const el = document.getElementById('wss-' + i);
  el.className = 'ws-step ' + status;
  const icon = el.querySelector('.ws-step-icon');
  if (status === 'done') icon.textContent = '✓';
  else if (status === 'skipped') icon.textContent = '–';
  else icon.textContent = '⟳';
}

function _wsAddLog(msg) {
  const logEl = document.getElementById('ws-log');
  const line = document.createElement('div');
  line.textContent = '[' + new Date().toLocaleTimeString('ro-RO', {hour:'2-digit',minute:'2-digit',second:'2-digit'}) + '] ' + msg;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}

function _buildWsConfig(agKey) {
  return {
    provider: cfg.wsProvider,
    model: cfg.wsModel,
    apiKey: cfg.wsApiKey,
    serverUrl: cfg.wsServerUrl,
    maxResults: cfg.wsMaxResults,
    maxFetch: cfg.wsMaxFetch,
    maxPageSize: cfg.wsMaxPageSize,
    briefThreshold: cfg.wsBriefThreshold,
    region: cfg.wsRegion,
    optPrompt: cfg.wsOptPrompt,
    rankPrompt: cfg.wsRankPrompt,
    relPrompt: cfg.wsRelPrompt,
    overviewPrompt: cfg.wsOverviewPrompt,
    summPrompt: cfg.wsSummPrompt,
    maxStoreResults: cfg.wsMaxStoreResults || 1,
    overviewEnabled: cfg.wsOverviewEnabled !== false,
    cacheTTL: cfg.wsCacheTTL ?? 7200,
    contextSize: cfg.wsCtx || 8192,
    multiQueryEnabled: cfg.wsMultiQueryEnabled === true,
    maxQueries: cfg.wsMaxQueries || 3,
    wsAdaptive: cfg.wsAdaptive === true,
    decompPrompt: cfg.wsDecompPrompt,
    multiSynthPrompt: cfg.wsMultiSynthPrompt,
  };
}

async function runWebSearch(agKey, reason, query) {
  if (!cfg.wsEnabled || !cfg.wsModel) {
    addSystemMsg('⚠ Web Search dezactivat sau model neconfigurat.');
    return null;
  }

  _wsResetModal();
  _wsUpdateChip(true);
  document.getElementById('ws-modal-status').textContent = 'Căutare...';
  document.getElementById('ws-query-display').textContent = `Query: ${query}`;
  document.getElementById('btn-ws-stop').style.display = 'inline-flex';
  _wsAbortCtrl = new AbortController();

  let finalResult = null;

  // Start background task
  let taskId = null;
  try {
    const startResp = await fetch('/api/websearch/start', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({reason, query, config: _buildWsConfig(agKey)}),
      // No abort signal here — we need the task_id even if browser closes immediately after
    });
    const startData = await startResp.json();
    taskId = startData.task_id;
    // Store task_id so we can reconnect after page refresh
    sessionStorage.setItem('_ws_task_id', taskId);
    sessionStorage.setItem('_ws_task_agKey', agKey);
  } catch(e) {
    if (e.name !== 'AbortError') {
      _wsAddLog('Eroare start task: ' + e.message);
      finalResult = {success: false, summary: 'Web search error: ' + e.message};
    }
  }

  if (taskId) {
    try {
      const resp = await fetch('/api/websearch/stream/' + taskId, {signal: _wsAbortCtrl.signal});
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const reader = resp.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        buf += dec.decode(value, {stream: true});
        const lines = buf.split('\n');
        buf = lines.pop();
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const obj = JSON.parse(line);
            if (obj.step !== undefined && obj.stepStatus) _wsSetStep(obj.step, obj.stepStatus);
            if (obj.log) _wsAddLog(obj.log);
            if (obj.stats) _wsSetLiveStats(obj.stats);
            if (obj.done) {
              finalResult = obj.result || null;
            }
          } catch(e) {}
        }
      }
    } catch(e) {
      if (e.name === 'AbortError') {
        // Browser refresh/close — keep task_id in sessionStorage for reconnect
        return;
      }
      _wsAddLog('Eroare stream: ' + e.message);
      finalResult = {success: false, summary: 'Web search error: ' + e.message};
    }
  }

  // Task completed normally — clear task_id
  sessionStorage.removeItem('_ws_task_id');
  sessionStorage.removeItem('_ws_task_agKey');

  _wsAbortCtrl = null;
  document.getElementById('btn-ws-stop').style.display = 'none';
  _wsUpdateChip(false);

  if (finalResult) {
    if (finalResult.success) {
      document.getElementById('ws-modal-status').textContent = '✓ Finalizat';
      // Stats row
      const statsRow = document.getElementById('ws-stats-row');
      statsRow.className = 'ws-stats-row show';
      const srcCount = finalResult.sourceCount || (finalResult.sourceUrl ? 1 : 0);
      const subq = finalResult.subQueryCount || 1;
      const chars = finalResult.contentSize || 0;
      statsRow.innerHTML =
        `<span class="ws-stat">Sub-queries: <span class="ws-stat-val">${subq}</span></span>` +
        `<span class="ws-stat">Surse relevante: <span class="ws-stat-val">${srcCount}</span></span>` +
        `<span class="ws-stat">Conținut: <span class="ws-stat-val">${(chars/1000).toFixed(1)}k chars</span></span>`;
      // Source row
      const resRow = document.getElementById('ws-result-row');
      resRow.className = 'ws-result-row show';
      if (srcCount > 1) {
        resRow.innerHTML = `<span>🔗 ${srcCount} surse:</span> ` +
          (finalResult.sources || []).map(s =>
            `<a class="ws-source-link" href="${escHtml(s.url)}" target="_blank">${escHtml(s.title || s.url)}</a>`
          ).join(' · ');
      } else if (finalResult.sourceUrl) {
        resRow.innerHTML = `Sursă: <a class="ws-source-link" href="${escHtml(finalResult.sourceUrl)}" target="_blank">${escHtml(finalResult.sourceTitle || finalResult.sourceUrl)}</a>`;
      } else {
        resRow.innerHTML = 'Rezultat fără URL sursă';
      }
    sessionStorage.removeItem('_ws_task_id');
    if (finalResult && finalResult.success) {
      addSystemMsg('✓ Căutare web finalizată după reconectare.');

      // Check if result already saved in discussion (refresh happened after WS but before agent response)
      const alreadyInCtx = state.discussion.some(e => e.role === 'wsresult');
      if (!alreadyInCtx && finalResult.summary) {
        state.discussion.push({role: 'system', content: finalResult.summary, step: state.stepCount});
        state.discussion.push({role: 'wsresult', content: JSON.stringify(finalResult), step: state.stepCount});
        state.discussion.push({role: 'user', content: '[INSTRUCȚIUNE SISTEM: Căutarea web s-a finalizat. Rezultatele sunt disponibile mai sus. Folosește aceste informații pentru a răspunde la întrebarea inițială. NU mai efectua alte căutări web.]', step: state.stepCount});
        autosaveDiscussion();
      }
        let wsAgKey = sessionStorage.getItem('_ws_task_agKey') || cfg.oneAgentKey || 'a';
        for (let i = state.discussion.length - 1; i >= 0; i--) {
          const e = state.discussion[i];
          if ((e.role === 'a' || e.role === 'b') && /WEB_SEARCH:/i.test(e.content)) {
            wsAgKey = e.role; break;
          }
