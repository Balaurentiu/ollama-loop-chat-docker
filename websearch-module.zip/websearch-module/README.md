# Modul Web Search — Ollama Loop Chat

## Descriere generală

Modulul de web search permite agenților AI să caute informații actualizate pe internet în timpul unei conversații. Când un agent are nevoie de date externe, emite un pattern special în răspuns, iar sistemul interceptează automat căutarea, execută pipeline-ul complet și reinjectează rezultatele în conversație.

---

## Arhitectură

```
Agent LLM
  └─ emite: REASON: <motiv>\nWEB_SEARCH: <query>
       │
       ▼
  [index.html — streamTurn]
  detectează pattern → state.pendingWebSearch
       │
       ▼
  [runWebSearch(agKey, reason, query)]
  POST /api/websearch/start  ──►  task_id
       │
       ▼
  GET /api/websearch/stream/<task_id>   (NDJSON streaming)
       │
       ▼
  [_stream_websearch]
  ┌─────────────────────────────────────┐
  │  1. LLM planifică sub-queries       │
  │  2. Pentru fiecare query:           │
  │     a. Cache check (SQLite)         │
  │     b. DuckDuckGo search            │
  │     c. Fetch + trafilatura extract  │
  │     d. LLM summarize per-page       │
  │  3. LLM sinteză finală              │
  └─────────────────────────────────────┘
       │
       ▼
  Rezultat injectat în state.discussion
  Agent continuă cu informațiile găsite
```

---

## Fișiere componente

| Fișier | Conținut |
|--------|----------|
| `websearch_module.py` | Tot codul Python: cache, fetch, pipeline, routes Flask |
| `websearch_client.js` | Cod JavaScript frontend: `runWebSearch()`, streaming, UI |

---

## Backend Python (`websearch_module.py`)

### Cache SQLite (`ws_cache.db`)

Stocat în `DATA_DIR` (implicit `%APPDATA%\OllamaChat\` pe Windows, lângă `server.py` altfel).

```python
_db_conn()        # context manager pentru conexiune SQLite
_db_init()        # crează tabela ws_cache la pornire
_cache_get(query_key, ttl_seconds)       # citire după query hash
_cache_get_by_url(url, ttl_seconds)      # citire după URL
_cache_store(...)                        # scriere
_cache_clear()                           # șterge tot
_cache_stats()                           # statistici
```

**Schema tabelei:**
```sql
CREATE TABLE ws_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query_key TEXT,      -- SHA256 al query-ului normalizat
    query TEXT,
    reason TEXT,
    url TEXT,
    title TEXT,
    summary TEXT,        -- rezumat generat de LLM
    full_content TEXT,   -- conținut extras de trafilatura
    content_size INTEGER,
    created_at REAL,     -- timestamp Unix
    success INTEGER
)
```

TTL implicit: **24 ore** (configurabil din settings).

### Fetch pagini (`_fetch_page_content`)

```python
_fetch_page_content(url, max_size=30000)
```

1. `requests.get(url, timeout=15)` cu User-Agent de browser
2. Încearcă **trafilatura** (extrage text curat, ignoră reclame/navigație)
3. Fallback: **BeautifulSoup** — extrage `<p>`, `<h1-h6>`, `<li>`, `<td>`
4. Returnează `(text, method)` unde `method` ∈ `{'html', 'bs4', 'error'}`

### DuckDuckGo search (`_search_ddg`)

```python
_search_ddg(query, max_results=5, region='wt-wt')
```

Folosește API-ul HTML al DDG (`https://html.duckduckgo.com/html/`) — fără API key necesar. Parsează rezultatele cu BeautifulSoup și returnează listă de `{title, url, snippet}`.

### Pipeline per query (`_run_single_query_pipeline`)

```python
_run_single_query_pipeline(query, reason, original_query, config, chunk, _today, _re, live_stats)
```

Execuție completă pentru un singur sub-query:
1. Verifică cache → returnează imediat dacă există
2. `_search_ddg` → listă URL-uri
3. Pentru fiecare URL (paralel cu `ThreadPoolExecutor`):
   - `_cache_get_by_url` (cache per URL)
   - `_fetch_page_content`
   - LLM summarize: prompt scurt, model configurabil
4. Stochează în cache
5. Emite chunks NDJSON cu progres live

### Stream engine (`_stream_websearch`)

Generatorul principal apelat de Flask:

```python
_stream_websearch(data)  # → generator de NDJSON chunks
```

**Parametri din `data` (POST body):**

| Parametru | Tip | Default | Descriere |
|-----------|-----|---------|-----------|
| `query` | string | — | Query-ul original al agentului |
| `reason` | string | `""` | Motivul căutării (context pentru LLM) |
| `config.provider` | string | `"ollama"` | Provider LLM pentru sumarizare |
| `config.model` | string | — | Modelul folosit pentru sumarizare |
| `config.wsMaxQueries` | int | `3` | Număr maxim sub-queries |
| `config.wsMaxResults` | int | `3` | Rezultate DDG per query |
| `config.wsCacheTtl` | int | `86400` | TTL cache în secunde |
| `config.wsSearchRegion` | string | `"wt-wt"` | Regiunea DDG |
| `config.wsSummaryModel` | string | `""` | Model separat pentru summary (opțional) |

**Flow intern:**
1. LLM planifică numărul de sub-queries și queries (prompt structurat → JSON)
2. Execută fiecare query prin `_run_single_query_pipeline` (secvențial)
3. Agregă toate rezultatele
4. LLM sinteză finală → răspuns complet pentru agent

**Chunks NDJSON emise:**
```json
{"type": "progress", "message": "...", "stats": {...}}
{"type": "result", "summary": "...", "sources": [...], "queries": [...]}
{"type": "error", "message": "..."}
```

### Routes Flask

| Route | Metodă | Descriere |
|-------|--------|-----------|
| `/api/websearch` | POST | Stream direct NDJSON (simplu) |
| `/api/websearch/start` | POST | Pornește task în background → `{task_id}` |
| `/api/websearch/stream/<task_id>` | GET | Stream chunks task existent |
| `/api/websearch/status` | GET | Lista task-urilor active/recente |
| `/api/ws-cache/clear` | POST | Golește cache-ul |
| `/api/ws-cache/stats` | GET | Statistici cache |

---

## Frontend JavaScript (`websearch_client.js`)

### `runWebSearch(agKey, reason, query)`

Funcția principală apelată din `runLoop()` când un agent emite pattern-ul de căutare.

**Flow:**
1. Pornește task async: `POST /api/websearch/start`
2. Deschide modal de progres
3. Streaming NDJSON: `GET /api/websearch/stream/<task_id>`
4. Parsează chunks și actualizează UI live
5. Returnează `{summary, sources, queries}` la final

### `stopWebSearch()`

Anulează `_wsAbortCtrl` (AbortController) și ascunde butonul Stop.

### Pattern detectat în răspunsul agentului

```
REASON: <motivul căutării>
WEB_SEARCH: <query concis>
```

Detectat în `streamTurn()` după ce streaming-ul se termină:
```javascript
const wsMatch = fullContent.match(/REASON:\s*([^\n]+)\n+WEB_SEARCH:\s*([^\n]{1,300})/)
```

Când e detectat: răspunsul agentului e tăiat înainte de pattern, se setează `state.pendingWebSearch`, iar loop-ul execută căutarea la următoarea iterație.

---

## Configurare (Settings → Web Search)

| Setare | ID | Default | Descriere |
|--------|----|---------|-----------|
| Provider sumarizare | `wsProvider` | ollama | Provider LLM pentru procesare |
| Model sumarizare | `wsModel` | — | Modelul folosit |
| Max sub-queries | `wsMaxQueries` | 3 | Câte query-uri paralele |
| Rezultate/query | `wsMaxResults` | 3 | Rezultate DDG per query |
| Cache TTL (ore) | `wsCacheTtl` | 24 | Durata cache |
| Regiune căutare | `wsSearchRegion` | wt-wt | Regiunea DDG |
| Model summary separat | `wsSummaryModel` | — | Override model pentru summarize |

---

## Dependențe Python

```
requests
beautifulsoup4
lxml
trafilatura>=2.0.0
```

**Notă trafilatura 2.0.0+:** necesită `use_config()` explicit:
```python
from trafilatura.settings import use_config
_tcfg = use_config()
text = trafilatura.extract(html, config=_tcfg)
```

---

## Notă integrare

Modulul este integrat direct în `server.py` (nu e un pachet separat). Pentru a-l reutiliza:
1. Copiați secțiunile marcate în `websearch_module.py`
2. Asigurați-vă că `DATA_DIR` este definit înainte de `_db_init()`
3. Apelați `_db_init()` la pornirea aplicației
4. Înregistrați routes-urile Flask în aplicația voastră
5. Includeți `websearch_client.js` în frontend și expuneți `runWebSearch()` din loop-ul de conversație
